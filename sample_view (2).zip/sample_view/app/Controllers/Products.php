<?php
namespace App\Controllers;

use App\Models\Products_model;

class Products extends BaseController {
    
    protected $products_model;

    public function __construct() {
        $this->products_model = new Products_model(); // Load model in constructor
    }

    public function index() {
        $data['page_title'] = 'Viewing Products List';
        $data['title'] = 'Viewing Products List';

        $data['products'] = $this->products_model->findAll();

        return view('productslist_view', $data);
    }

    public function add() {
        $data['title'] = 'Add New Product';
        $data['page_title'] = 'Add New Product';

        if ($this->request->getMethod() == 'post') {
            // Make sure these keys match your form input names
            $post_data = $this->request->getPost(['ProductName', 'ProductAmount']);
            $this->products_model->insert($post_data);
            return redirect()->to(base_url('products')); // Redirect to products index
        }

        return view('addproduct_view', $data);
    }

    public function view($id) {
        $data['title'] = 'Product Details';
        $data['page_title'] = 'Product Details';

        $data['product'] = $this->products_model->find($id); // Fetch the product by ID

        // Check if the product exists
        if (!$data['product']) {
            return redirect()->to(base_url('products'))->with('error', 'Product not found'); // Redirect with error message
        }

        return view('productsdetails_view', $data);
    }
}


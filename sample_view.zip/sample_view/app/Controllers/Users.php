<?php
namespace App\Controllers;

class Users extends BaseController{

    public function index(){
        $data['page_title'] = 'Viewing Users List';
        $data['title'] = 'Viewing Users List'; // this is to pass the value to title on view

         

        // Create an instance of your model
        $user_model = new \App\Models\Users_model();
        // Use the the built-in query builder of the model class
        $data['users'] = $user_model->findAll(); // show data from table

        return view('userslist_view', $data); // call this view with data to be pass
        }
    
        public function add(){
            $data['title'] = 'Add New User';
            $data['page_title'] = 'Add New User';
            if($this->request->getMethod() == 'POST'){
            // Capture all data entered into the form
            $post_data = $this->request->getPost(['username', 'password',
            'fullname', 'email']);
            $user_model = new \App\Models\Users_model();
            $user_model->insert($post_data);
            return redirect()->to('users/index');
            }
            return view('adduser_view', $data);
            }

            public function view($id){
                $data['title'] = 'Add New User';
                $data['page_title'] = 'Add New User';
                $user_model = new \App\Models\Users_model();
                $data['user'] = $user_model->find($id);
                return view('userdetails_view', $data);
                }
                

 }
?>
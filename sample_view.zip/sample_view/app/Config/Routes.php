<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
 $routes->get('/', 'Home::index');

$routes->get('users','Users::index');
// https://localhost/code_projects/user this is how to access on the web browser

$routes->get('users/test','Users::test');
https://localhost/code_projects/users/test this is how to access on the web browser


$routes->get('users/test/(:any)','Users::test/$1');

$routes->get('users/test/(:any)/(:any)','Users::test/$1/$2');
//https://localhost/code_projects/users/test/Adidas/123

$routes->get('/','Users::index');
$routes->get('users','Users::index');
$routes->get('users/index','Users::index');
$routes->get('users/add', 'Users::add');
$routes->post('users/add', 'Users::add');
$routes->get('users/view/(:num)', 'Users::view/$1');